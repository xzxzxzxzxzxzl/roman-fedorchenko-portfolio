const projects=[
 {title:"KITO Air One",category:"E-commerce · аудио",description:"Концепция рекламной подачи проводных наушников. Контрастный бордовый фон и крупный предметный рендер помогают сосредоточить внимание на форме продукта.",images:["assets/headphones.png","assets/headphones2.png"]},
 {title:"MDR Ultra Light",category:"Digital · техника",description:"Концепт первого экрана страницы дрона. Тёмная сцена, крупный заголовок и центральное изображение выстраивают премиальную подачу продукта.",images:["assets/dron2.png"]},
 {title:"Whoosh",category:"Digital · уход",description:"Концепт страницы фена с акцентом на силуэт и детали продукта. Светлый фон оставляет пространство для крупного предметного изображения.",images:["assets/fen!.png"]},
 {title:"Портативный блендер",category:"E-commerce · техника",description:"Промо-карточка портативного блендера. Яркая палитра, крупный продукт и короткие подписи выделяют ключевые особенности товара.",images:["assets/blender.png"]},
 {title:"X’Flow Gym",category:"Digital · фитнес",description:"Концепт главного экрана сайта фитнес-клуба. Неоновый цвет, крупная типографика и модульные блоки задают энергичный характер проекта.",images:["assets/FitnesClub.png"]},
 {title:"Nerva No.07",category:"Графика · парфюм",description:"Концептуальный постер аромата с пластичной графикой, приглушёнными оттенками и выразительной типографикой.",images:["assets/Parfum.png"]},
 {title:"After Midnight",category:"Графика · афиша",description:"Афиша ночного кинопоказа. Атмосферные постеры фильмов, тёмный фон и лаконичная сетка создают единый визуальный ритм.",images:["assets/kino.png"]},
 {title:"Static Heart",category:"Графика · музыка",description:"Концепция обложки музыкального альбома. Чёрно-белая сцена и центральная фигура задают сдержанное кинематографичное настроение.",images:["assets/album.png"]}
];
const cards=[...document.querySelectorAll('.project-card')];
const dialog=document.querySelector('.project-dialog');
const visual=dialog.querySelector('.dialog-visual');
const title=dialog.querySelector('#dialog-title');
const category=dialog.querySelector('.dialog-category');
const description=dialog.querySelector('.dialog-description');
const thumbnails=dialog.querySelector('.dialog-thumbnails');
const counter=dialog.querySelector('.dialog-counter');
let current=0;let imageIndex=0;
function renderProject(){const project=projects[current];const path=project.images[imageIndex];title.textContent=project.title;category.textContent=project.category;description.textContent=project.description;visual.replaceChildren();const img=document.createElement('img');img.src=path;img.alt=project.title+' — изображение '+(imageIndex+1);visual.append(img);thumbnails.replaceChildren();project.images.forEach((src,index)=>{const button=document.createElement('button');button.type='button';button.className=index===imageIndex?'is-active':'';button.setAttribute('aria-label','Показать изображение '+(index+1));const thumb=document.createElement('img');thumb.src=src;thumb.alt='';button.append(thumb);button.addEventListener('click',()=>{imageIndex=index;renderProject()});thumbnails.append(button)});thumbnails.hidden=project.images.length<2;counter.textContent=String(current+1).padStart(2,'0')+' / '+String(projects.length).padStart(2,'0')+(project.images.length>1?' · '+String(imageIndex+1).padStart(2,'0')+' / '+String(project.images.length).padStart(2,'0'):'')}
function openProject(index){current=index;imageIndex=0;renderProject();dialog.showModal();document.body.classList.add('dialog-open')}
function moveProject(direction){current=(current+direction+projects.length)%projects.length;imageIndex=0;renderProject()}
cards.forEach(card=>{card.addEventListener('click',()=>openProject(Number(card.dataset.project)));card.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();openProject(Number(card.dataset.project))}})});
document.querySelectorAll('.filter').forEach(button=>button.addEventListener('click',()=>{document.querySelectorAll('.filter').forEach(item=>{const active=item===button;item.classList.toggle('is-active',active);item.setAttribute('aria-pressed',String(active))});const filter=button.dataset.filter;cards.forEach(card=>{card.hidden=filter!=='all'&&card.dataset.category!==filter})}));
dialog.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());dialog.querySelector('.dialog-prev').addEventListener('click',()=>moveProject(-1));dialog.querySelector('.dialog-next').addEventListener('click',()=>moveProject(1));dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close()});dialog.addEventListener('close',()=>document.body.classList.remove('dialog-open'));document.addEventListener('keydown',event=>{if(!dialog.open)return;if(event.key==='ArrowLeft')moveProject(-1);if(event.key==='ArrowRight')moveProject(1)});document.querySelector('#year').textContent=new Date().getFullYear();
